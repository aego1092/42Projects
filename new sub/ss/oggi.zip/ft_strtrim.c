/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ddi-nico <ddi-nico@student.42roma.it>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/17 16:56:54 by ddi-nico          #+#    #+#             */
/*   Updated: 2026/06/17 16:57:44 by ddi-nico         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include <stddef.h>
#include <stdlib.h>
char	*ft_strnstr(const char *big, const char *little, size_t len);
char	*ft_strdup(const char *s);
char	*ft_strjoin(char const *s1, char const *s2);

char    *ft_strtrim(char const *s1, char const *set)
{	
    char    *sub_str;
    char    *substr_memory;
    int     i;
    int     j;

    i = 0;
    j = 0;
    while (i < ft_strlen(s1))
    {
        sub_str = ft_strnstr(s1[i + j * ft_strlen(set)], set, (ft_strlen(s1[i + j * ft_strlen(set)])));
        if (sub_str != NULL)
		    j++;
        i++;
    }
    if (sub_str == NULL)
		return (s1);
    substr_memory = malloc((ft_strlen(sub_str) + 1) * sizeof(*s1));
	if (substr_memory == NULL)
		return (NULL);
    return (sub_str);
}